import base44 from "@base44/vite-plugin"
import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  // Carga .env en tiempo de configuración (antes de que exista import.meta.env
  // en el navegador). Esto es lo que permite decidir aquí, a nivel de Vite,
  // si Base44 está realmente configurado — no solo a nivel de React.
  const env = loadEnv(mode, process.cwd(), '');
  const base44Configured = !!env.VITE_BASE44_APP_ID;

  return {
    plugins: [
      base44({
        // Support for legacy code that imports the base44 SDK with @/integrations, @/entities, etc.
        // can be removed if the code has been updated to use the new SDK imports from @base44/sdk
        legacySDKImports: process.env.BASE44_LEGACY_SDK_IMPORTS === 'true',
        // Estos 4 "notifiers" del plugin de Base44 corren a nivel del
        // servidor de dev y llaman a la API de Base44 en cada navegación/HMR,
        // usando la configuración interna del propio plugin. Si Base44 no
        // está configurado (sin VITE_BASE44_APP_ID), esas llamadas de fondo
        // devuelven 404 — este es el origen real del error reportado
        // ("/api/apps/auth/login 404" al hacer clic en "Create one", que
        // solo cambia de ruta con React Router y no debería tocar red).
        // Se desactivan automáticamente cuando Base44 no está configurado.
        hmrNotifier: base44Configured,
        navigationNotifier: base44Configured,
        analyticsTracker: base44Configured,
        visualEditAgent: base44Configured,
      }),
      react(),
    ],
  };
});
