import { createClient } from '@base44/sdk';
import { appParams, normalizeEnvValue } from '@/lib/app-params';

const { appId, token, functionsVersion, appBaseUrl } = appParams;

// ── Guardián de validación — corrige la causa raíz del bug reportado ──
// Antes, createClient() se llamaba SIEMPRE con lo que appParams trajera,
// incluso si appId era inválido (null, "null", vacío). Esto producía un
// cliente Base44 real que sí intentaba hacer peticiones de red con un
// app_id inválido, resultando en 404 (ej. /api/apps/auth/login).
// Ahora: si appId no pasa la validación, el SDK NUNCA se inicializa, se
// informa exactamente por consola qué variable falló, y se exporta un
// stub que lanza un error claro apenas alguien intente usarlo — en vez de
// fallar en silencio con una petición de red rota.
const normalizedAppId = normalizeEnvValue(appId);

function logInvalidConfig() {
  console.error(
    '[base44Client] Base44 NO se inicializó — appId inválido o no configurado.\n' +
    `  Valor recibido: ${JSON.stringify(appId)}\n` +
    '  Revisa VITE_BASE44_APP_ID en tu .env (debe estar vacío/ausente si no usas Base44, ' +
    'o tener el app_id real de tu dashboard de Base44 — nunca el texto "null").\n' +
    '  Vivi seguirá funcionando en modo local/Firebase para autenticación ' +
    '(ver src/lib/authMode.js) — este stub solo afecta llamadas directas a base44.entities/integrations.'
  );
}

function createUnconfiguredStub() {
  return new Proxy({}, {
    get(_target, prop) {
      throw new Error(
        `[base44Client] Se intentó acceder a "base44.${String(prop)}" pero Base44 no está configurado ` +
        '(appId inválido o ausente). Configura VITE_BASE44_APP_ID en tu .env con un valor real, ' +
        'o usa el modo local/Firebase (ver src/lib/authMode.js).'
      );
    },
  });
}

if (!normalizedAppId) {
  logInvalidConfig();
}

//Create a client with authentication required — SOLO si appId es válido.
export const base44 = normalizedAppId
  ? createClient({
      appId: normalizedAppId,
      token,
      functionsVersion,
      serverUrl: '',
      requiresAuth: false,
      appBaseUrl
    })
  : createUnconfiguredStub();
